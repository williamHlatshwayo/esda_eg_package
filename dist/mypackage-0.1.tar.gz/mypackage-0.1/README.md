# esda_eg_package
This library was created as an example pf how to publish your own Python package with Explore Data Science Academy.